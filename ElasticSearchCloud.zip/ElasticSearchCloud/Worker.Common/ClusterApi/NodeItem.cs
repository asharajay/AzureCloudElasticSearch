﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElasticsearchWorker.IndexResponse
{
    public class NodeItem
    {
        public string name { get; set; }
        public string transport_address { get; set; }
    }
}
