﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElasticsearchWorker.IndexResponse
{
    public class ClusterHealth
    {
        public string status { get; set; }
    }
}
