﻿
namespace ElasticsearchWorker.Core
{
    public class ElasticsearchNode
    {
        public string Ip { get; set; }
        public int Port { get; set; }
        public string NodeName { get; set; }
        public string Status { get; set; }
    }
}
